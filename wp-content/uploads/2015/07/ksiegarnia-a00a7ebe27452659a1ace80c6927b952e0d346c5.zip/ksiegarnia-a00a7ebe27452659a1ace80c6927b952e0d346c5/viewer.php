<?php
include 'classes/domain/book.php';
include 'classes/repository/bookRepository.php';
//include 'index.php';
echo $_GET["title"];
$newitem = $_GET["title"];
?>